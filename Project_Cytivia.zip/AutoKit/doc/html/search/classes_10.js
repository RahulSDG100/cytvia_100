var searchData=
[
  ['xmlreader_318',['XmlReader',['../classcom_1_1common_1_1framework_1_1data_manager_1_1_xml_reader.html',1,'com::common::framework::dataManager']]]
];
