var searchData=
[
  ['log_2etxt_374',['log.txt',['../log_8txt.html',1,'']]],
  ['logmanager_2ejava_375',['LogManager.java',['../_log_manager_8java.html',1,'']]]
];
